--
-- PostgreSQL database dump
--

\restrict OtOFxxfQjP3P1oxI0HrK7WMJvIlhTG0JRrdF0iR6xX8IbFIVyefaQ2lXvdsvM11

-- Dumped from database version 16.16
-- Dumped by pg_dump version 16.16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tares161fixture; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA tares161fixture;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_runs; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.agent_runs (
    id text NOT NULL,
    agent text,
    trigger text,
    dispatch_id text,
    key_value text,
    status text,
    rounds integer,
    tool_calls integer,
    prompt_hash text,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    duration_ms integer,
    finding text,
    error text,
    external_tools text,
    max_rounds integer,
    model text,
    input_tokens bigint,
    output_tokens bigint,
    cache_creation_input_tokens bigint,
    cache_read_input_tokens bigint,
    cost_usd double precision,
    delivery text,
    delivery_error text,
    provider text,
    outcome text,
    verdict text,
    results text,
    skills text,
    woken_by text,
    parent_run_id text,
    project text,
    headline text,
    next_step text,
    handled_at timestamp with time zone,
    handled_by text,
    what_changed text,
    since_at timestamp with time zone,
    failing text,
    likely_cause text,
    practice boolean
);


--
-- Name: answers; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.answers (
    id text NOT NULL,
    item text,
    kind text,
    project text,
    ask text,
    choice text,
    said text,
    via text,
    person_id text,
    answered_at timestamp with time zone
);


--
-- Name: api_keys; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.api_keys (
    id text NOT NULL,
    name text,
    prefix text,
    hash text,
    scopes text,
    created_at timestamp with time zone,
    last_used_at timestamp with time zone,
    revoked_at timestamp with time zone,
    project text,
    person_id text
);


--
-- Name: ask_sessions; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.ask_sessions (
    id text NOT NULL,
    title text,
    state text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    person_id text
);


--
-- Name: assumptions; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.assumptions (
    id text NOT NULL,
    project text,
    number integer,
    question text,
    choice text,
    why text,
    affects text,
    tickets text,
    state text,
    words text,
    batch text,
    made_by text,
    made_role text,
    made_at timestamp with time zone,
    decided_at timestamp with time zone,
    person_id text
);


--
-- Name: brain_calls; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.brain_calls (
    id text NOT NULL,
    at timestamp with time zone,
    tool text,
    deep integer DEFAULT 0,
    question text,
    repos text,
    duration_ms integer,
    input_tokens integer,
    output_tokens integer,
    ok integer,
    error text,
    station text,
    person_id text,
    via text
);


--
-- Name: brain_repo_folders; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.brain_repo_folders (
    repo text NOT NULL,
    path text NOT NULL,
    chosen_by text,
    chosen_at timestamp with time zone
);


--
-- Name: brain_repo_updates; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.brain_repo_updates (
    id text NOT NULL,
    repo text,
    at timestamp with time zone,
    kind text,
    ok integer,
    indexed_commit text,
    files_changed integer,
    files_deleted integer,
    files_total integer,
    error text
);


--
-- Name: brain_repos; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.brain_repos (
    repo text NOT NULL,
    repo_source_id text,
    state text,
    files_done integer DEFAULT 0,
    files_total integer DEFAULT 0,
    indexed_commit text,
    last_synced timestamp with time zone,
    error text,
    added_by text,
    added_at timestamp with time zone,
    place integer,
    job_started_at timestamp with time zone,
    sync_failures integer DEFAULT 0,
    sync_error text
);


--
-- Name: catalog_agents; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.catalog_agents (
    name text NOT NULL,
    trigger text,
    prompt text,
    slack_webhook text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    model text,
    slack_channel text,
    webhook_url text,
    webhook_token text,
    mcp_servers text,
    max_rounds integer,
    budget_usd double precision,
    budget_period text,
    daily_cap integer,
    owned_by text,
    customized boolean,
    webhook_key_label text,
    provider text,
    handoffs text,
    concludes boolean,
    github text,
    verdicts text
);


--
-- Name: catalog_sources; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.catalog_sources (
    name text NOT NULL,
    type text,
    connector text,
    poll text,
    config text,
    paused boolean DEFAULT false,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    ingest_key text,
    owned_by text,
    customized boolean
);


--
-- Name: catalog_triggers; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.catalog_triggers (
    name text NOT NULL,
    sources text,
    filters text,
    key_field text,
    condition text,
    emit text,
    cooldown text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    paused boolean DEFAULT false,
    owned_by text,
    customized boolean,
    description text
);


--
-- Name: challenges; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.challenges (
    source text NOT NULL,
    key_value text NOT NULL,
    event_time timestamp with time zone NOT NULL,
    event_type text NOT NULL,
    branch text NOT NULL,
    tares_project text,
    payload text
);


--
-- Name: crews; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.crews (
    id text NOT NULL,
    name text,
    person_id text,
    machine text,
    first_seen timestamp with time zone,
    last_seen timestamp with time zone
);


--
-- Name: decisions; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.decisions (
    id text NOT NULL,
    project text,
    desk_item text,
    question text,
    words text,
    choice text,
    standing boolean,
    scope text,
    matched boolean,
    session text,
    granted boolean,
    tickets text,
    decided_at timestamp with time zone,
    via text,
    person_id text
);


--
-- Name: desk_items; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.desk_items (
    id text NOT NULL,
    number integer,
    project text,
    question text,
    context text,
    options text,
    recommendation text,
    why text,
    blocks text,
    tickets text,
    blocking boolean,
    asked_by text,
    assumptions text,
    state text,
    reason text,
    created_at timestamp with time zone,
    closed_at timestamp with time zone,
    station text,
    command text,
    person_id text,
    to_person_id text
);


--
-- Name: dispatch_deliveries; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.dispatch_deliveries (
    dispatch_id text,
    subscription_id text,
    url text,
    ok boolean,
    delivered_at timestamp with time zone,
    error text
);


--
-- Name: dispatch_log; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.dispatch_log (
    dispatch_id text NOT NULL,
    trigger text,
    key_value text,
    kind text,
    fired_at timestamp with time zone,
    subscribers integer,
    delivered integer,
    payload text,
    project text,
    parent_run_id text,
    practice boolean
);


--
-- Name: dispatch_projects; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.dispatch_projects (
    dispatch_id text NOT NULL,
    project text NOT NULL
);


--
-- Name: docs; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.docs (
    id text NOT NULL,
    kind text,
    title text,
    body text,
    made_by text,
    updated_by text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    owner text
);


--
-- Name: finding_feedback; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.finding_feedback (
    run_id text NOT NULL,
    person text NOT NULL,
    person_name text,
    worth boolean,
    note text,
    via text,
    watcher text,
    watcher_run text,
    dispatch_id text,
    project text,
    answered_at timestamp with time zone
);


--
-- Name: github_credentials; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.github_credentials (
    name text NOT NULL,
    kind text,
    token text,
    api_url text,
    account text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    config text
);


--
-- Name: grants; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.grants (
    id text NOT NULL,
    kind text,
    project text,
    holder_person_id text,
    words text,
    given_by text,
    given_at timestamp with time zone,
    areas text,
    consents text,
    state text,
    needs_lead boolean DEFAULT false
);


--
-- Name: guardrail_pairs; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.guardrail_pairs (
    id text NOT NULL,
    scope text,
    project_uid text,
    hook text,
    integration text,
    settings text,
    on_fail text DEFAULT 'block'::text,
    created_at timestamp with time zone,
    created_by text
);


--
-- Name: guardrail_rules; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.guardrail_rules (
    id text NOT NULL,
    scope text,
    project text,
    kind text,
    text text,
    created_by text,
    created_at timestamp with time zone
);


--
-- Name: handover_overrides; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.handover_overrides (
    project text,
    at timestamp with time zone,
    reason text,
    person_id text,
    handed_by text
);


--
-- Name: handovers; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.handovers (
    project text NOT NULL,
    repo text,
    handed_by text,
    handed_at timestamp with time zone,
    repos text,
    autonomy text,
    finished_at timestamp with time zone,
    finished_words text,
    finished_decision text,
    finished_by text,
    taken_at timestamp with time zone,
    taken_words text,
    taken_by text,
    released_at timestamp with time zone,
    person_id text,
    finished_person_id text,
    taken_person_id text,
    crew text,
    override_reason text,
    override_at timestamp with time zone,
    override_person_id text
);


--
-- Name: incident_log; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.incident_log (
    incident_id text,
    at_time timestamp with time zone,
    action text,
    by_id text,
    by_name text,
    via text
);


--
-- Name: incident_notes; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.incident_notes (
    run_id text NOT NULL,
    incident_id text,
    joined_at timestamp with time zone,
    slack_channel text,
    slack_ts text
);


--
-- Name: incidents; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.incidents (
    id text NOT NULL,
    service text,
    project text,
    state text,
    opened_at timestamp with time zone,
    last_note_at timestamp with time zone,
    owner text,
    owner_name text,
    owner_at timestamp with time zone,
    resolved_at timestamp with time zone,
    resolved_by text,
    resolved_by_name text,
    resolution text,
    slack text,
    updated_at timestamp with time zone,
    slack_url text
);


--
-- Name: integration_choices; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.integration_choices (
    slot text NOT NULL,
    name text,
    settings text,
    updated_at timestamp with time zone,
    updated_by text
);


--
-- Name: integration_connections; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.integration_connections (
    slot text NOT NULL,
    name text NOT NULL,
    settings text,
    updated_at timestamp with time zone,
    updated_by text
);


--
-- Name: mcp_servers; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.mcp_servers (
    name text NOT NULL,
    url text,
    auth_header text,
    auth_value text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    headers text,
    owned_by text,
    customized boolean
);


--
-- Name: merge_queue; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.merge_queue (
    id text NOT NULL,
    repo text,
    base text,
    pr integer,
    head text,
    ticket text,
    project_uid text,
    state text,
    reason text,
    desk_item text,
    approved_head text,
    entered_at timestamp with time zone,
    updated_at timestamp with time zone,
    before_files text,
    unknown_ticks integer
);


--
-- Name: merge_records; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.merge_records (
    queue_row text NOT NULL,
    project text,
    ticket text,
    repo text,
    pr integer,
    level text,
    reviewed_sha text,
    merged_sha text,
    rounds integer,
    ci_state text,
    approver_id text,
    approved_at timestamp with time zone,
    merged_at timestamp with time zone,
    outside boolean
);


--
-- Name: milestone_acceptances; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.milestone_acceptances (
    milestone text NOT NULL,
    project text,
    by_name text,
    person_id text,
    accepted_at timestamp with time zone
);


--
-- Name: milestone_check_results; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.milestone_check_results (
    id text NOT NULL,
    project text,
    milestone text,
    idx integer,
    result text,
    note text,
    by_kind text,
    by_name text,
    person_id text,
    checked_at timestamp with time zone
);


--
-- Name: milestones; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.milestones (
    id text NOT NULL,
    project text,
    owner text,
    external_id text,
    name text,
    goal text,
    checks text,
    "position" double precision,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: model_usage; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.model_usage (
    id text NOT NULL,
    ts timestamp with time zone,
    surface text,
    agent text,
    run_id text,
    model text,
    calls integer,
    input_tokens bigint,
    output_tokens bigint,
    cache_creation_input_tokens bigint,
    cache_read_input_tokens bigint,
    cost_usd double precision,
    key_source text,
    provider text
);


--
-- Name: pending_memory; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.pending_memory (
    id text NOT NULL,
    scope text,
    line text,
    attempts integer DEFAULT 0,
    last_error text,
    created_at timestamp with time zone,
    tried_at timestamp with time zone
);


--
-- Name: pending_writeback; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.pending_writeback (
    ticket text NOT NULL,
    integration text NOT NULL,
    status text,
    attempts integer,
    last_error text,
    updated_at timestamp with time zone
);


--
-- Name: people; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.people (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    emails text,
    github text,
    is_admin boolean DEFAULT false,
    created_at timestamp with time zone,
    created_via text,
    picture text,
    removed_at timestamp with time zone
);


--
-- Name: project_integrations; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.project_integrations (
    project_uid text NOT NULL,
    slot text NOT NULL,
    name text,
    settings text,
    updated_at timestamp with time zone,
    updated_by text
);


--
-- Name: project_members; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.project_members (
    project text NOT NULL,
    person_id text NOT NULL,
    added_by text,
    added_at timestamp with time zone,
    reason text
);


--
-- Name: project_merge_method; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.project_merge_method (
    project text NOT NULL,
    method text,
    updated_at timestamp with time zone,
    updated_by text
);


--
-- Name: project_required_checks; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.project_required_checks (
    project text NOT NULL,
    commands text,
    updated_at timestamp with time zone,
    updated_by text
);


--
-- Name: project_secrets; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.project_secrets (
    project text NOT NULL,
    name text NOT NULL,
    value text,
    set_by text,
    set_at timestamp with time zone,
    used_by text,
    used_at timestamp with time zone
);


--
-- Name: project_sessions; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.project_sessions (
    project text NOT NULL,
    session text NOT NULL,
    repo text,
    linked_at timestamp with time zone
);


--
-- Name: project_wiring; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.project_wiring (
    project text,
    kind text,
    trigger text,
    agent text,
    from_agent text,
    verdict text,
    cooldown text,
    enabled boolean,
    created_at timestamp with time zone
);


--
-- Name: query_log; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.query_log (
    id text NOT NULL,
    scope text,
    key_value text,
    time_window text,
    rows_returned integer,
    client text,
    queried_at timestamp with time zone,
    project text
);


--
-- Name: repo_map_history; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.repo_map_history (
    repo text,
    changed_at timestamp with time zone,
    by_station text,
    project text,
    note text
);


--
-- Name: repo_maps; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.repo_maps (
    repo text NOT NULL,
    body text,
    updated_at timestamp with time zone,
    updated_by text
);


--
-- Name: report_texts; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.report_texts (
    kind text NOT NULL,
    key text NOT NULL,
    text text,
    source text,
    figures text,
    written_at timestamp with time zone
);


--
-- Name: report_weeks; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.report_weeks (
    project text NOT NULL,
    week date NOT NULL,
    merged integer,
    start_to_merge text,
    stage_hours text,
    waited_hours double precision,
    milestones_accepted integer,
    reviewed integer,
    passed_first integer,
    rounds text,
    findings text,
    questions text,
    cost_usd double precision,
    unpriced integer,
    cost_by_role text,
    updated_at timestamp with time zone
);


--
-- Name: review_findings; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.review_findings (
    id text NOT NULL,
    project text,
    ticket text,
    review text,
    number integer,
    severity text,
    file text,
    line integer,
    blocking boolean,
    text text,
    kind text,
    state text,
    fixed_in text,
    found_at timestamp with time zone
);


--
-- Name: reviews; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.reviews (
    id text NOT NULL,
    project text,
    ticket text,
    round integer,
    pr text,
    head text,
    verdict text,
    verified text,
    not_verified text,
    by_station text,
    reviewed_at timestamp with time zone,
    person_id text
);


--
-- Name: rule_proposals; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.rule_proposals (
    id text NOT NULL,
    repo text,
    kind text,
    project text,
    scope text,
    text text,
    tickets text,
    state text,
    created_at timestamp with time zone,
    decided_at timestamp with time zone
);


--
-- Name: run_projects; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.run_projects (
    run_id text NOT NULL,
    project text NOT NULL
);


--
-- Name: services; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.services (
    name text NOT NULL,
    display text,
    hidden boolean,
    merged_into text,
    repos text,
    updated_at timestamp with time zone,
    updated_by text
);


--
-- Name: session_archive_parts; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_archive_parts (
    session text NOT NULL,
    part integer NOT NULL,
    first_seq integer,
    last_seq integer,
    lines integer,
    bytes bigint,
    md5 text,
    key text,
    written_at timestamp with time zone
);


--
-- Name: session_commands; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_commands (
    tool_use_id text NOT NULL,
    source text,
    session text,
    at timestamp with time zone,
    command text,
    exit_code integer,
    output_tail text,
    result_at timestamp with time zone,
    cwd text,
    outcome text
);


--
-- Name: session_files; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_files (
    session text NOT NULL,
    path text NOT NULL,
    source text,
    last_at timestamp with time zone
);


--
-- Name: session_ingest_marks; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_ingest_marks (
    name text NOT NULL,
    at timestamp with time zone
);


--
-- Name: session_lines; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_lines (
    session text NOT NULL,
    seq integer NOT NULL,
    line_key text,
    at timestamp with time zone,
    type text,
    labels text,
    render text,
    payload text
);


--
-- Name: session_messages; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_messages (
    tool_use_id text NOT NULL,
    source text,
    session text,
    at timestamp with time zone,
    to_station text,
    type text,
    text text
);


--
-- Name: session_meters; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_meters (
    session text NOT NULL,
    status text,
    status_at timestamp with time zone,
    context text,
    context_at timestamp with time zone,
    context_asked_at timestamp with time zone,
    status_person text
);


--
-- Name: session_moves; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_moves (
    session text NOT NULL,
    state text NOT NULL,
    target text,
    lines_events integer,
    lines_after integer,
    started_at timestamp with time zone,
    verified_at timestamp with time zone,
    error text,
    attempts integer
);


--
-- Name: session_rollup_state; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_rollup_state (
    name text NOT NULL,
    cursor text,
    ready_at timestamp with time zone
);


--
-- Name: session_said; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_said (
    session text NOT NULL,
    line_key text NOT NULL,
    source text,
    at timestamp with time zone,
    text text
);


--
-- Name: session_states; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_states (
    session text NOT NULL,
    state text,
    reason text,
    state_at timestamp with time zone
);


--
-- Name: session_stations; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_stations (
    session text NOT NULL,
    station text,
    role text,
    parent text,
    project text,
    seen_at timestamp with time zone,
    crew_id text,
    runtime text,
    model text
);


--
-- Name: session_store_copies; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_store_copies (
    table_name text NOT NULL,
    rows integer,
    copied_at timestamp with time zone
);


--
-- Name: session_store_version; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_store_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: session_turns; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_turns (
    session text NOT NULL,
    line_key text NOT NULL,
    source text,
    at timestamp with time zone,
    person text,
    text text
);


--
-- Name: session_usage; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_usage (
    session text NOT NULL,
    message text NOT NULL,
    replied_at timestamp with time zone,
    model text,
    project text,
    subagent text,
    input_tokens bigint,
    output_tokens bigint,
    cache_write_tokens bigint,
    cache_read_tokens bigint,
    cost_usd double precision,
    cache_write_1h_tokens bigint
);


--
-- Name: session_usage_hourly; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.session_usage_hourly (
    session text NOT NULL,
    hour timestamp with time zone NOT NULL,
    project text DEFAULT ''::text NOT NULL,
    replies bigint NOT NULL,
    input_tokens bigint NOT NULL,
    output_tokens bigint NOT NULL,
    cache_write_tokens bigint NOT NULL,
    cache_read_tokens bigint NOT NULL,
    cost_usd double precision,
    unpriced bigint NOT NULL
);


--
-- Name: sessions; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.sessions (
    session text NOT NULL,
    source text,
    started_at timestamp with time zone,
    last_line_at timestamp with time zone,
    line_count integer DEFAULT 0 NOT NULL,
    tool_calls integer DEFAULT 0 NOT NULL,
    coordination_calls integer DEFAULT 0 NOT NULL,
    lines_complete boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone,
    lines_origin text
);


--
-- Name: settings; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.settings (
    key text NOT NULL,
    value text,
    updated_at timestamp with time zone
);


--
-- Name: shared_skills; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.shared_skills (
    name text NOT NULL,
    description text,
    body text,
    made_by text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    updated_by text
);


--
-- Name: signoffs; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.signoffs (
    project text NOT NULL,
    repo text NOT NULL,
    person_id text,
    at timestamp with time zone,
    via text
);


--
-- Name: skills; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.skills (
    project text NOT NULL,
    name text NOT NULL,
    description text,
    body text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: spec_questions; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.spec_questions (
    project text NOT NULL,
    id text NOT NULL,
    to_person_id text,
    repo text,
    text text,
    asked_by text,
    asked_at timestamp with time zone,
    answer text,
    answered_by text,
    answered_at timestamp with time zone,
    state text,
    via text
);


--
-- Name: subscriptions; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.subscriptions (
    subscription_id text NOT NULL,
    trigger text,
    url text,
    created_at timestamp with time zone,
    created_by text,
    project text
);


--
-- Name: tares_state_meta; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.tares_state_meta (
    key text NOT NULL,
    value text,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: ticket_checks; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.ticket_checks (
    id text NOT NULL,
    project text,
    ticket text,
    command text,
    result text,
    commit_sha text,
    broke_test text,
    by_station text,
    by_session text,
    checked_at timestamp with time zone,
    person_id text
);


--
-- Name: ticket_history; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.ticket_history (
    ticket text,
    project text,
    changed_at timestamp with time zone,
    field text,
    value text,
    reason text,
    by_station text,
    by_role text,
    person_id text
);


--
-- Name: ticket_numbers; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.ticket_numbers (
    project text NOT NULL,
    last integer
);


--
-- Name: tickets; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.tickets (
    id text NOT NULL,
    project text,
    owner text,
    external_id text,
    identifier text,
    url text,
    title text,
    status text,
    "position" double precision,
    working_doc text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    milestone text,
    depends_on text,
    number integer,
    holder text,
    stage text,
    stage_reason text,
    pr text,
    repo text,
    assignee_person_id text,
    assignee_raw text,
    pr_repo text,
    pr_number bigint
);


--
-- Name: trigger_state; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.trigger_state (
    trigger text NOT NULL,
    key_value text NOT NULL,
    last_fired timestamp with time zone
);


--
-- Name: usecase_log; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.usecase_log (
    usecase_id text,
    logged_at timestamp with time zone,
    action text,
    detail text
);


--
-- Name: usecase_objects; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.usecase_objects (
    usecase_id text NOT NULL,
    kind text NOT NULL,
    key text NOT NULL,
    name text,
    customized boolean,
    created_at timestamp with time zone
);


--
-- Name: usecases; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.usecases (
    id text NOT NULL,
    recipe text,
    name text,
    params text,
    status text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    last_error text,
    goal text,
    setup text,
    linear text,
    github_issues text,
    kind text,
    lead_person_id text,
    scope text,
    icon text
);


--
-- Name: waiting_told; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.waiting_told (
    person_id text NOT NULL,
    item text NOT NULL,
    told_at timestamp with time zone,
    sent boolean,
    ask text,
    channel text,
    ts text,
    seq integer,
    closed text
);


--
-- Name: watch_state; Type: TABLE; Schema: tares161fixture; Owner: -
--

CREATE TABLE tares161fixture.watch_state (
    service text NOT NULL,
    watched boolean,
    reason text,
    since timestamp with time zone,
    agent text,
    project text,
    told_at timestamp with time zone,
    told_where text
);


--
-- Data for Name: agent_runs; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: answers; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.api_keys VALUES ('key_fixture01', 'ada-laptop', 'nvf_key_fixture01', 'ff766410b1985ecc2fc4cf5a2e1a999b672ebab1345127708399740cdea393b2', '["ingest", "read"]', '2026-11-28 10:11:41.584577+00', NULL, NULL, NULL, 'p_0db1325ec6');


--
-- Data for Name: ask_sessions; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: assumptions; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: brain_calls; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: brain_repo_folders; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: brain_repo_updates; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: brain_repos; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: catalog_agents; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: catalog_sources; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.catalog_sources VALUES ('github', 'event_stream', 'github_app', '5s', '{"credential": "fx-app"}', false, '2026-11-28 10:11:41.588027+00', '2026-11-28 10:11:41.588027+00', 'github_app-fixture00000001', NULL, NULL);
INSERT INTO tares161fixture.catalog_sources VALUES ('gh-poll', 'event_stream', 'github', '60s', '{"credential": "fx-token", "repo": "example-org/lantern"}', false, '2026-11-28 10:11:41.592526+00', '2026-11-28 10:11:41.592526+00', 'github-93c444ce', NULL, NULL);
INSERT INTO tares161fixture.catalog_sources VALUES ('claude_code', 'event_stream', 'claude_code', '5s', '{"push": true}', false, '2026-11-28 10:11:41.594509+00', '2026-11-28 10:11:41.594509+00', 'claude_code-c76d4e02', NULL, NULL);
INSERT INTO tares161fixture.catalog_sources VALUES ('cc_old', 'event_stream', 'claude_code', '5s', '{"push": true, "redact": false, "include_thinking": true}', false, '2026-11-28 10:11:41.596428+00', '2026-11-28 10:11:41.596428+00', 'claude_code-20b21e26', NULL, NULL);


--
-- Data for Name: catalog_triggers; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: challenges; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: crews; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.crews VALUES ('c_038df9d3c0', 'crew', 'local', '', '2026-11-20 07:00:00+00', '2026-11-20 07:00:00+00');


--
-- Data for Name: decisions; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.decisions VALUES ('dc_88d67cde4d', 'uc_lantern01', 'dk_3c92d98dca', 'Which date format?', 'ISO please', 'ISO', false, 'project', true, NULL, false, '["tk_31865dfed5"]', '2026-11-20 11:30:00+00', 'console', 'p_0db1325ec6');


--
-- Data for Name: desk_items; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.desk_items VALUES ('dk_3c92d98dca', 1, 'uc_lantern01', 'Which date format?', 'exports', '["ISO", "US"]', 'ISO', 'it sorts', NULL, '["tk_31865dfed5"]', false, 'lantern-build-m1', '[]', 'open', NULL, '2026-11-20 11:00:00+00', NULL, NULL, NULL, NULL, NULL);


--
-- Data for Name: dispatch_deliveries; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: dispatch_log; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: dispatch_projects; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: docs; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.docs VALUES ('doc_051d096eda', 'spec', 'Lantern spec', 'The spec of billing.', 'uc_lantern01', NULL, '2026-11-28 10:11:41.619152+00', '2026-11-28 10:11:41.619152+00', NULL);
INSERT INTO tares161fixture.docs VALUES ('doc_5c3a3a7eea', 'plan', 'Harbor plan', 'The plan.', 'uc_harbor002', NULL, '2026-11-28 10:11:41.626108+00', '2026-11-28 10:11:41.626108+00', NULL);


--
-- Data for Name: finding_feedback; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: github_credentials; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.github_credentials VALUES ('fx-app', 'app', '', '', 'example-org', '2026-11-28 10:11:41.586074+00', '2026-11-28 10:11:41.586074+00', '{"app_id": 99, "slug": "fixture-app", "webhook_secret": "fixture-webhook-secret", "installations": [{"id": 4242, "account": "example-org", "account_type": "Organization", "repository_selection": "all"}]}');
INSERT INTO tares161fixture.github_credentials VALUES ('fx-token', 'token', 'ghp_fixture', '', '', '2026-11-28 10:11:41.590176+00', '2026-11-28 10:11:41.590176+00', NULL);


--
-- Data for Name: grants; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: guardrail_pairs; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: guardrail_rules; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: handover_overrides; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: handovers; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: incident_log; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: incident_notes; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: incidents; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: integration_choices; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: integration_connections; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: mcp_servers; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: merge_queue; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: merge_records; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: milestone_acceptances; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: milestone_check_results; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: milestones; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.milestones VALUES ('ms_5a657b77e3', 'uc_lantern01', 'tares', NULL, 'M1: first pages', 'The pages are live.', '[{"check": "open the home page", "for": "it loads"}]', 1, '2026-11-28 10:11:41.638235+00', '2026-11-28 10:11:41.638235+00');


--
-- Data for Name: model_usage; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: pending_memory; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: pending_writeback; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: people; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.people VALUES ('local', 'You', NULL, '[]', NULL, true, '2026-11-28 10:11:41.386313+00', 'boot', NULL, NULL);
INSERT INTO tares161fixture.people VALUES ('p_0db1325ec6', 'Ada Quill', 'ada.quill@example.com', '[]', NULL, true, '2026-11-28 10:11:41.581514+00', 'admin', NULL, NULL);


--
-- Data for Name: project_integrations; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: project_members; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.project_members VALUES ('uc_harbor002', 'p_0db1325ec6', NULL, '2026-11-28 10:11:41.615543+00', 'manual');


--
-- Data for Name: project_merge_method; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: project_required_checks; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: project_secrets; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: project_sessions; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.project_sessions VALUES ('uc_lantern01', '11111111-0000-4000-a000-000000000001', 'lantern', '2026-11-28 10:11:41.808449+00');
INSERT INTO tares161fixture.project_sessions VALUES ('uc_harbor002', '11111111-0000-4000-a000-000000000002', 'lantern', '2026-11-28 10:11:41.875664+00');
INSERT INTO tares161fixture.project_sessions VALUES ('uc_lantern01', '11111111-0000-4000-a000-000000000004', 'lantern', '2026-11-28 10:11:41.967696+00');


--
-- Data for Name: project_wiring; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: query_log; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: repo_map_history; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: repo_maps; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: report_texts; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: report_weeks; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: review_findings; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.review_findings VALUES ('rf_52fcd48ff4', 'uc_lantern01', 'tk_7db9aedf80', 'rv_9c26ab702c', 1, 'P2', 'cart.py', 12, true, 'The empty list is not handled.', 'null or empty', 'open', NULL, '2026-11-20 10:00:00+00');


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.reviews VALUES ('rv_9c26ab702c', 'uc_lantern01', 'tk_7db9aedf80', 1, 'https://github.com/example-org/lantern/pull/7', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'changes', 'the tests', 'the docs', 'lantern-reviewer', '2026-11-20 10:00:00+00', 'p_0db1325ec6');


--
-- Data for Name: rule_proposals; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: run_projects; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: services; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: session_archive_parts; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.session_archive_parts VALUES ('11111111-0000-4000-a000-000000000004', 1, 1, 10, 10, 979, 'ff128d6e0585c6ccf77d05dc391effb0', '11111111-0000-4000-a000-000000000004/1.jsonl.gz', '2026-11-20 12:00:00+00');


--
-- Data for Name: session_commands; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.session_commands VALUES ('toolu_a_0', 'claude_code', '11111111-0000-4000-a000-000000000001', '2026-11-20 07:01:30+00', 'pytest -q tests/test_cart.py', 0, '12 passed in 3.1s', '2026-11-20 07:02:00+00', NULL, NULL);
INSERT INTO tares161fixture.session_commands VALUES ('toolu_a_1', 'claude_code', '11111111-0000-4000-a000-000000000001', '2026-11-20 07:03:30+00', 'pytest -q tests/test_cart.py', 0, '12 passed in 3.1s', '2026-11-20 07:04:00+00', NULL, NULL);
INSERT INTO tares161fixture.session_commands VALUES ('toolu_a_2', 'claude_code', '11111111-0000-4000-a000-000000000001', '2026-11-20 07:05:30+00', 'pytest -q tests/test_cart.py', 0, '12 passed in 3.1s', '2026-11-20 07:06:00+00', NULL, NULL);
INSERT INTO tares161fixture.session_commands VALUES ('toolu_b_0', 'claude_code', '11111111-0000-4000-a000-000000000002', '2026-11-20 08:01:30+00', 'pytest -q tests/test_cart.py', 0, '12 passed in 3.1s', '2026-11-20 08:02:00+00', NULL, NULL);
INSERT INTO tares161fixture.session_commands VALUES ('toolu_b_1', 'claude_code', '11111111-0000-4000-a000-000000000002', '2026-11-20 08:03:30+00', 'pytest -q tests/test_cart.py', 0, '12 passed in 3.1s', '2026-11-20 08:04:00+00', NULL, NULL);
INSERT INTO tares161fixture.session_commands VALUES ('toolu_c_0', 'cc_old', '11111111-0000-4000-a000-000000000003', '2026-11-20 09:01:30+00', 'pytest -q tests/test_cart.py', 0, '12 passed in 3.1s', '2026-11-20 09:02:00+00', NULL, NULL);
INSERT INTO tares161fixture.session_commands VALUES ('toolu_c_1', 'cc_old', '11111111-0000-4000-a000-000000000003', '2026-11-20 09:03:30+00', 'pytest -q tests/test_cart.py', 0, '12 passed in 3.1s', '2026-11-20 09:04:00+00', NULL, NULL);
INSERT INTO tares161fixture.session_commands VALUES ('toolu_d_0', 'claude_code', '11111111-0000-4000-a000-000000000004', '2026-11-10 12:01:30+00', 'pytest -q tests/test_cart.py', 0, '12 passed in 3.1s', '2026-11-10 12:02:00+00', NULL, NULL);
INSERT INTO tares161fixture.session_commands VALUES ('toolu_d_1', 'claude_code', '11111111-0000-4000-a000-000000000004', '2026-11-10 12:03:30+00', 'pytest -q tests/test_cart.py', 0, '12 passed in 3.1s', '2026-11-10 12:04:00+00', NULL, NULL);
INSERT INTO tares161fixture.session_commands VALUES ('toolu_e_0', 'claude_code', '11111111-0000-4000-a000-000000000005', '2026-11-20 10:01:30+00', 'pytest -q tests/test_cart.py', 0, '12 passed in 3.1s', '2026-11-20 10:02:00+00', NULL, NULL);
INSERT INTO tares161fixture.session_commands VALUES ('toolu_e_1', 'claude_code', '11111111-0000-4000-a000-000000000005', '2026-11-20 10:03:30+00', 'pytest -q tests/test_cart.py', 0, '12 passed in 3.1s', '2026-11-20 10:04:00+00', NULL, NULL);
INSERT INTO tares161fixture.session_commands VALUES ('toolu_f_0', 'claude_code', '11111111-0000-4000-a000-000000000006', '2026-11-20 11:01:30+00', 'pytest -q tests/test_cart.py', 0, '12 passed in 3.1s', '2026-11-20 11:02:00+00', NULL, NULL);


--
-- Data for Name: session_files; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: session_ingest_marks; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.session_ingest_marks VALUES ('sessions_caught_up', '2026-11-28 10:11:41.433181+00');
INSERT INTO tares161fixture.session_ingest_marks VALUES ('session_move_planned', '2026-11-28 10:11:42.018851+00');


--
-- Data for Name: session_lines; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000001', 1, '9079beba2e7742135748e3539e91b62ac00a84b4f611a444fd4009c0e0709087', '2026-11-20 07:00:00+00', 'session_station', '{"session": "11111111-0000-4000-a000-000000000001", "type": "session_station", "sidechain": "false", "tares_project": "uc_lantern01"}', '{"include_thinking": false, "redact": true}', '{"type": "session_station", "sessionId": "11111111-0000-4000-a000-000000000001", "timestamp": "2026-11-20T07:00:00Z", "station": "lantern-build-m1", "role": "builder", "parent": "lantern-orchestrator", "tares_project": "uc_lantern01"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000001', 2, '9ebfc336aa147f0aaca256aab9061d5b4debb6644acf34651f101cfd7db758dd', '2026-11-20 07:00:00+00', 'session_project', '{"session": "11111111-0000-4000-a000-000000000001", "repo": "lantern", "type": "session_project", "sidechain": "false", "tares_project": "uc_lantern01"}', '{"include_thinking": false, "redact": true}', '{"type": "session_project", "sessionId": "11111111-0000-4000-a000-000000000001", "timestamp": "2026-11-20T07:00:00Z", "tares_project": "uc_lantern01", "cwd": "/work/lantern"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000001', 3, 'a-0001', '2026-11-20 07:00:30+00', 'user', '{"session": "11111111-0000-4000-a000-000000000001", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false", "tares_project": "uc_lantern01", "station": "lantern-build-m1"}', '{"include_thinking": false, "redact": true}', '{"type": "user", "uuid": "a-0001", "sessionId": "11111111-0000-4000-a000-000000000001", "timestamp": "2026-11-20T07:00:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": "please run the checks, round 1"}, "tares_project": "uc_lantern01", "factory_station": "lantern-build-m1"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000001', 4, 'a-0002', '2026-11-20 07:01:00+00', 'assistant', '{"session": "11111111-0000-4000-a000-000000000001", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false", "tares_project": "uc_lantern01", "station": "lantern-build-m1"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "a-0002", "sessionId": "11111111-0000-4000-a000-000000000001", "timestamp": "2026-11-20T07:01:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_a_0", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "thinking", "thinking": "the tests first"}, {"type": "text", "text": "I will run the tests (round 1)."}], "usage": {"input_tokens": 100, "output_tokens": 20, "cache_creation_input_tokens": 5, "cache_read_input_tokens": 50}}, "tares_project": "uc_lantern01", "factory_station": "lantern-build-m1"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000001', 5, 'a-0003', '2026-11-20 07:01:30+00', 'tool_use', '{"session": "11111111-0000-4000-a000-000000000001", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false", "tares_project": "uc_lantern01", "station": "lantern-build-m1"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "a-0003", "sessionId": "11111111-0000-4000-a000-000000000001", "timestamp": "2026-11-20T07:01:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_a_0b", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "tool_use", "id": "toolu_a_0", "name": "Bash", "input": {"command": "pytest -q tests/test_cart.py"}}], "usage": {"input_tokens": 10, "output_tokens": 5}}, "tares_project": "uc_lantern01", "factory_station": "lantern-build-m1"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000001', 6, 'a-0004', '2026-11-20 07:02:00+00', 'tool_result', '{"session": "11111111-0000-4000-a000-000000000001", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false", "tares_project": "uc_lantern01", "station": "lantern-build-m1"}', '{"include_thinking": false, "redact": true}', '{"type": "user", "uuid": "a-0004", "sessionId": "11111111-0000-4000-a000-000000000001", "timestamp": "2026-11-20T07:02:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "toolu_a_0", "content": "12 passed in 3.1s", "is_error": false}]}, "tares_project": "uc_lantern01", "factory_station": "lantern-build-m1"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000001', 7, 'a-0005', '2026-11-20 07:02:30+00', 'user', '{"session": "11111111-0000-4000-a000-000000000001", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false", "tares_project": "uc_lantern01", "station": "lantern-build-m1"}', '{"include_thinking": false, "redact": true}', '{"type": "user", "uuid": "a-0005", "sessionId": "11111111-0000-4000-a000-000000000001", "timestamp": "2026-11-20T07:02:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": "please run the checks, round 2"}, "tares_project": "uc_lantern01", "factory_station": "lantern-build-m1"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000001', 8, 'a-0006', '2026-11-20 07:03:00+00', 'assistant', '{"session": "11111111-0000-4000-a000-000000000001", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false", "tares_project": "uc_lantern01", "station": "lantern-build-m1"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "a-0006", "sessionId": "11111111-0000-4000-a000-000000000001", "timestamp": "2026-11-20T07:03:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_a_1", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "thinking", "thinking": "the tests first"}, {"type": "text", "text": "I will run the tests (round 2)."}], "usage": {"input_tokens": 101, "output_tokens": 20, "cache_creation_input_tokens": 5, "cache_read_input_tokens": 50}}, "tares_project": "uc_lantern01", "factory_station": "lantern-build-m1"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000001', 9, 'a-0007', '2026-11-20 07:03:30+00', 'tool_use', '{"session": "11111111-0000-4000-a000-000000000001", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false", "tares_project": "uc_lantern01", "station": "lantern-build-m1"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "a-0007", "sessionId": "11111111-0000-4000-a000-000000000001", "timestamp": "2026-11-20T07:03:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_a_1b", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "tool_use", "id": "toolu_a_1", "name": "Bash", "input": {"command": "pytest -q tests/test_cart.py"}}], "usage": {"input_tokens": 10, "output_tokens": 5}}, "tares_project": "uc_lantern01", "factory_station": "lantern-build-m1"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000001', 10, 'a-0008', '2026-11-20 07:04:00+00', 'tool_result', '{"session": "11111111-0000-4000-a000-000000000001", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false", "tares_project": "uc_lantern01", "station": "lantern-build-m1"}', '{"include_thinking": false, "redact": true}', '{"type": "user", "uuid": "a-0008", "sessionId": "11111111-0000-4000-a000-000000000001", "timestamp": "2026-11-20T07:04:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "toolu_a_1", "content": "12 passed in 3.1s", "is_error": false}]}, "tares_project": "uc_lantern01", "factory_station": "lantern-build-m1"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000001', 11, 'a-0009', '2026-11-20 07:04:30+00', 'user', '{"session": "11111111-0000-4000-a000-000000000001", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false", "tares_project": "uc_lantern01", "station": "lantern-build-m1"}', '{"include_thinking": false, "redact": true}', '{"type": "user", "uuid": "a-0009", "sessionId": "11111111-0000-4000-a000-000000000001", "timestamp": "2026-11-20T07:04:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": "please run the checks, round 3"}, "tares_project": "uc_lantern01", "factory_station": "lantern-build-m1"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000001', 12, 'a-0010', '2026-11-20 07:05:00+00', 'assistant', '{"session": "11111111-0000-4000-a000-000000000001", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false", "tares_project": "uc_lantern01", "station": "lantern-build-m1"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "a-0010", "sessionId": "11111111-0000-4000-a000-000000000001", "timestamp": "2026-11-20T07:05:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_a_2", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "thinking", "thinking": "the tests first"}, {"type": "text", "text": "I will run the tests (round 3)."}], "usage": {"input_tokens": 102, "output_tokens": 20, "cache_creation_input_tokens": 5, "cache_read_input_tokens": 50}}, "tares_project": "uc_lantern01", "factory_station": "lantern-build-m1"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000001', 13, 'a-0011', '2026-11-20 07:05:30+00', 'tool_use', '{"session": "11111111-0000-4000-a000-000000000001", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false", "tares_project": "uc_lantern01", "station": "lantern-build-m1"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "a-0011", "sessionId": "11111111-0000-4000-a000-000000000001", "timestamp": "2026-11-20T07:05:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_a_2b", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "tool_use", "id": "toolu_a_2", "name": "Bash", "input": {"command": "pytest -q tests/test_cart.py"}}], "usage": {"input_tokens": 10, "output_tokens": 5}}, "tares_project": "uc_lantern01", "factory_station": "lantern-build-m1"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000001', 14, 'a-0012', '2026-11-20 07:06:00+00', 'tool_result', '{"session": "11111111-0000-4000-a000-000000000001", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false", "tares_project": "uc_lantern01", "station": "lantern-build-m1"}', '{"include_thinking": false, "redact": true}', '{"type": "user", "uuid": "a-0012", "sessionId": "11111111-0000-4000-a000-000000000001", "timestamp": "2026-11-20T07:06:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "toolu_a_2", "content": "12 passed in 3.1s", "is_error": false}]}, "tares_project": "uc_lantern01", "factory_station": "lantern-build-m1"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000001', 15, 'a-0013', '2026-11-20 07:06:30+00', 'tool_use', '{"session": "11111111-0000-4000-a000-000000000001", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false", "tares_project": "uc_lantern01", "station": "lantern-build-m1"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "a-0013", "sessionId": "11111111-0000-4000-a000-000000000001", "timestamp": "2026-11-20T07:06:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_a_send", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "tool_use", "id": "toolu_a_send", "name": "SendMessage", "input": {"to": "lantern-orchestrator", "message": "[TF:DONE] LAN-1 is ready for review"}}], "usage": {"input_tokens": 10, "output_tokens": 5}}, "tares_project": "uc_lantern01", "factory_station": "lantern-build-m1"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000002', 1, '2fc57b16e85e734cb72e8291dd8f6cd6f87c56c52ac8c38282ee052585975b95', '2026-11-20 08:00:00+00', 'session_project', '{"session": "11111111-0000-4000-a000-000000000002", "repo": "lantern", "type": "session_project", "sidechain": "false", "tares_project": "uc_harbor002"}', '{"include_thinking": false, "redact": true}', '{"type": "session_project", "sessionId": "11111111-0000-4000-a000-000000000002", "timestamp": "2026-11-20T08:00:00Z", "tares_project": "uc_harbor002", "cwd": "/work/lantern"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000002', 2, 'b-0001', '2026-11-20 08:00:30+00', 'user', '{"session": "11111111-0000-4000-a000-000000000002", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false", "tares_project": "uc_harbor002"}', '{"include_thinking": false, "redact": true}', '{"type": "user", "uuid": "b-0001", "sessionId": "11111111-0000-4000-a000-000000000002", "timestamp": "2026-11-20T08:00:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": "please run the checks, round 1"}, "tares_project": "uc_harbor002"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000002', 3, 'b-0002', '2026-11-20 08:01:00+00', 'assistant', '{"session": "11111111-0000-4000-a000-000000000002", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false", "tares_project": "uc_harbor002"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "b-0002", "sessionId": "11111111-0000-4000-a000-000000000002", "timestamp": "2026-11-20T08:01:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_b_0", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "thinking", "thinking": "the tests first"}, {"type": "text", "text": "I will run the tests (round 1)."}], "usage": {"input_tokens": 100, "output_tokens": 20, "cache_creation_input_tokens": 5, "cache_read_input_tokens": 50}}, "tares_project": "uc_harbor002"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000002', 4, 'b-0003', '2026-11-20 08:01:30+00', 'tool_use', '{"session": "11111111-0000-4000-a000-000000000002", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false", "tares_project": "uc_harbor002"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "b-0003", "sessionId": "11111111-0000-4000-a000-000000000002", "timestamp": "2026-11-20T08:01:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_b_0b", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "tool_use", "id": "toolu_b_0", "name": "Bash", "input": {"command": "pytest -q tests/test_cart.py"}}], "usage": {"input_tokens": 10, "output_tokens": 5}}, "tares_project": "uc_harbor002"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000002', 5, 'b-0004', '2026-11-20 08:02:00+00', 'tool_result', '{"session": "11111111-0000-4000-a000-000000000002", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false", "tares_project": "uc_harbor002"}', '{"include_thinking": false, "redact": true}', '{"type": "user", "uuid": "b-0004", "sessionId": "11111111-0000-4000-a000-000000000002", "timestamp": "2026-11-20T08:02:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "toolu_b_0", "content": "12 passed in 3.1s", "is_error": false}]}, "tares_project": "uc_harbor002"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000002', 6, 'b-0005', '2026-11-20 08:02:30+00', 'user', '{"session": "11111111-0000-4000-a000-000000000002", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false", "tares_project": "uc_harbor002"}', '{"include_thinking": false, "redact": true}', '{"type": "user", "uuid": "b-0005", "sessionId": "11111111-0000-4000-a000-000000000002", "timestamp": "2026-11-20T08:02:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": "please run the checks, round 2"}, "tares_project": "uc_harbor002"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000002', 7, 'b-0006', '2026-11-20 08:03:00+00', 'assistant', '{"session": "11111111-0000-4000-a000-000000000002", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false", "tares_project": "uc_harbor002"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "b-0006", "sessionId": "11111111-0000-4000-a000-000000000002", "timestamp": "2026-11-20T08:03:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_b_1", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "thinking", "thinking": "the tests first"}, {"type": "text", "text": "I will run the tests (round 2)."}], "usage": {"input_tokens": 101, "output_tokens": 20, "cache_creation_input_tokens": 5, "cache_read_input_tokens": 50}}, "tares_project": "uc_harbor002"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000002', 8, 'b-0007', '2026-11-20 08:03:30+00', 'tool_use', '{"session": "11111111-0000-4000-a000-000000000002", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false", "tares_project": "uc_harbor002"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "b-0007", "sessionId": "11111111-0000-4000-a000-000000000002", "timestamp": "2026-11-20T08:03:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_b_1b", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "tool_use", "id": "toolu_b_1", "name": "Bash", "input": {"command": "pytest -q tests/test_cart.py"}}], "usage": {"input_tokens": 10, "output_tokens": 5}}, "tares_project": "uc_harbor002"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000002', 9, 'b-0008', '2026-11-20 08:04:00+00', 'tool_result', '{"session": "11111111-0000-4000-a000-000000000002", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false", "tares_project": "uc_harbor002"}', '{"include_thinking": false, "redact": true}', '{"type": "user", "uuid": "b-0008", "sessionId": "11111111-0000-4000-a000-000000000002", "timestamp": "2026-11-20T08:04:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "toolu_b_1", "content": "12 passed in 3.1s", "is_error": false}]}, "tares_project": "uc_harbor002"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000002', 10, 'b-0009', '2026-11-20 08:04:30+00', 'tool_use', '{"session": "11111111-0000-4000-a000-000000000002", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false", "tares_project": "uc_harbor002"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "b-0009", "sessionId": "11111111-0000-4000-a000-000000000002", "timestamp": "2026-11-20T08:04:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_b_send", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "tool_use", "id": "toolu_b_send", "name": "SendMessage", "input": {"to": "lantern-orchestrator", "message": "[TF:DONE] LAN-1 is ready for review"}}], "usage": {"input_tokens": 10, "output_tokens": 5}}, "tares_project": "uc_harbor002"}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000003', 1, 'c-0001', '2026-11-20 09:00:30+00', 'user', '{"session": "11111111-0000-4000-a000-000000000003", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false"}', '{"include_thinking": true, "redact": false}', '{"type": "user", "uuid": "c-0001", "sessionId": "11111111-0000-4000-a000-000000000003", "timestamp": "2026-11-20T09:00:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": "please run the checks, round 1"}}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000003', 2, 'c-0002', '2026-11-20 09:01:00+00', 'assistant', '{"session": "11111111-0000-4000-a000-000000000003", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false"}', '{"include_thinking": true, "redact": false}', '{"type": "assistant", "uuid": "c-0002", "sessionId": "11111111-0000-4000-a000-000000000003", "timestamp": "2026-11-20T09:01:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_c_0", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "thinking", "thinking": "the tests first"}, {"type": "text", "text": "I will run the tests (round 1)."}], "usage": {"input_tokens": 100, "output_tokens": 20, "cache_creation_input_tokens": 5, "cache_read_input_tokens": 50}}}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000003', 3, 'c-0003', '2026-11-20 09:01:30+00', 'tool_use', '{"session": "11111111-0000-4000-a000-000000000003", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false"}', '{"include_thinking": true, "redact": false}', '{"type": "assistant", "uuid": "c-0003", "sessionId": "11111111-0000-4000-a000-000000000003", "timestamp": "2026-11-20T09:01:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_c_0b", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "tool_use", "id": "toolu_c_0", "name": "Bash", "input": {"command": "pytest -q tests/test_cart.py"}}], "usage": {"input_tokens": 10, "output_tokens": 5}}}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000003', 4, 'c-0004', '2026-11-20 09:02:00+00', 'tool_result', '{"session": "11111111-0000-4000-a000-000000000003", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false"}', '{"include_thinking": true, "redact": false}', '{"type": "user", "uuid": "c-0004", "sessionId": "11111111-0000-4000-a000-000000000003", "timestamp": "2026-11-20T09:02:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "toolu_c_0", "content": "12 passed in 3.1s", "is_error": false}]}}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000003', 5, 'c-0005', '2026-11-20 09:02:30+00', 'user', '{"session": "11111111-0000-4000-a000-000000000003", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false"}', '{"include_thinking": true, "redact": false}', '{"type": "user", "uuid": "c-0005", "sessionId": "11111111-0000-4000-a000-000000000003", "timestamp": "2026-11-20T09:02:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": "please run the checks, round 2"}}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000003', 6, 'c-0006', '2026-11-20 09:03:00+00', 'assistant', '{"session": "11111111-0000-4000-a000-000000000003", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false"}', '{"include_thinking": true, "redact": false}', '{"type": "assistant", "uuid": "c-0006", "sessionId": "11111111-0000-4000-a000-000000000003", "timestamp": "2026-11-20T09:03:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_c_1", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "thinking", "thinking": "the tests first"}, {"type": "text", "text": "I will run the tests (round 2)."}], "usage": {"input_tokens": 101, "output_tokens": 20, "cache_creation_input_tokens": 5, "cache_read_input_tokens": 50}}}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000003', 7, 'c-0007', '2026-11-20 09:03:30+00', 'tool_use', '{"session": "11111111-0000-4000-a000-000000000003", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false"}', '{"include_thinking": true, "redact": false}', '{"type": "assistant", "uuid": "c-0007", "sessionId": "11111111-0000-4000-a000-000000000003", "timestamp": "2026-11-20T09:03:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_c_1b", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "tool_use", "id": "toolu_c_1", "name": "Bash", "input": {"command": "pytest -q tests/test_cart.py"}}], "usage": {"input_tokens": 10, "output_tokens": 5}}}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000003', 8, 'c-0008', '2026-11-20 09:04:00+00', 'tool_result', '{"session": "11111111-0000-4000-a000-000000000003", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false"}', '{"include_thinking": true, "redact": false}', '{"type": "user", "uuid": "c-0008", "sessionId": "11111111-0000-4000-a000-000000000003", "timestamp": "2026-11-20T09:04:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "toolu_c_1", "content": "12 passed in 3.1s", "is_error": false}]}}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000003', 9, 'c-0009', '2026-11-20 09:04:30+00', 'tool_use', '{"session": "11111111-0000-4000-a000-000000000003", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false"}', '{"include_thinking": true, "redact": false}', '{"type": "assistant", "uuid": "c-0009", "sessionId": "11111111-0000-4000-a000-000000000003", "timestamp": "2026-11-20T09:04:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_c_send", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "tool_use", "id": "toolu_c_send", "name": "SendMessage", "input": {"to": "lantern-orchestrator", "message": "[TF:DONE] LAN-1 is ready for review"}}], "usage": {"input_tokens": 10, "output_tokens": 5}}}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000005', 1, 'e-0001', '2026-11-20 10:00:30+00', 'user', '{"session": "11111111-0000-4000-a000-000000000005", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false"}', '{"include_thinking": false, "redact": true}', '{"type": "user", "uuid": "e-0001", "sessionId": "11111111-0000-4000-a000-000000000005", "timestamp": "2026-11-20T10:00:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": "please run the checks, round 1"}}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000005', 2, 'e-0002', '2026-11-20 10:01:00+00', 'assistant', '{"session": "11111111-0000-4000-a000-000000000005", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "e-0002", "sessionId": "11111111-0000-4000-a000-000000000005", "timestamp": "2026-11-20T10:01:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_e_0", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "thinking", "thinking": "the tests first"}, {"type": "text", "text": "I will run the tests (round 1)."}], "usage": {"input_tokens": 100, "output_tokens": 20, "cache_creation_input_tokens": 5, "cache_read_input_tokens": 50}}}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000005', 3, 'e-0003', '2026-11-20 10:01:30+00', 'tool_use', '{"session": "11111111-0000-4000-a000-000000000005", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "e-0003", "sessionId": "11111111-0000-4000-a000-000000000005", "timestamp": "2026-11-20T10:01:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_e_0b", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "tool_use", "id": "toolu_e_0", "name": "Bash", "input": {"command": "pytest -q tests/test_cart.py"}}], "usage": {"input_tokens": 10, "output_tokens": 5}}}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000005', 4, 'e-0004', '2026-11-20 10:02:00+00', 'tool_result', '{"session": "11111111-0000-4000-a000-000000000005", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false"}', '{"include_thinking": false, "redact": true}', '{"type": "user", "uuid": "e-0004", "sessionId": "11111111-0000-4000-a000-000000000005", "timestamp": "2026-11-20T10:02:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "toolu_e_0", "content": "12 passed in 3.1s", "is_error": false}]}}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000006', 2, 'f-0002', '2026-11-20 11:01:00+00', 'assistant', '{"session": "11111111-0000-4000-a000-000000000006", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "f-0002", "sessionId": "11111111-0000-4000-a000-000000000006", "timestamp": "2026-11-20T11:01:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_f_0", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "thinking", "thinking": "the tests first"}, {"type": "text", "text": "I will run the tests (round 1)."}], "usage": {"input_tokens": 100, "output_tokens": 20, "cache_creation_input_tokens": 5, "cache_read_input_tokens": 50}}}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000006', 3, 'f-0003', '2026-11-20 11:01:30+00', 'tool_use', '{"session": "11111111-0000-4000-a000-000000000006", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "f-0003", "sessionId": "11111111-0000-4000-a000-000000000006", "timestamp": "2026-11-20T11:01:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_f_0b", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "tool_use", "id": "toolu_f_0", "name": "Bash", "input": {"command": "pytest -q tests/test_cart.py"}}], "usage": {"input_tokens": 10, "output_tokens": 5}}}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000006', 4, 'f-0004', '2026-11-20 11:02:00+00', 'tool_result', '{"session": "11111111-0000-4000-a000-000000000006", "repo": "lantern", "branch": "factory/LAN-1", "type": "user", "sidechain": "false"}', '{"include_thinking": false, "redact": true}', '{"type": "user", "uuid": "f-0004", "sessionId": "11111111-0000-4000-a000-000000000006", "timestamp": "2026-11-20T11:02:00Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "toolu_f_0", "content": "12 passed in 3.1s", "is_error": false}]}}');
INSERT INTO tares161fixture.session_lines VALUES ('11111111-0000-4000-a000-000000000006', 5, 'f-0005', '2026-11-20 11:02:30+00', 'tool_use', '{"session": "11111111-0000-4000-a000-000000000006", "repo": "lantern", "branch": "factory/LAN-1", "model": "claude-opus-5-5", "type": "assistant", "sidechain": "false"}', '{"include_thinking": false, "redact": true}', '{"type": "assistant", "uuid": "f-0005", "sessionId": "11111111-0000-4000-a000-000000000006", "timestamp": "2026-11-20T11:02:30Z", "cwd": "/work/lantern", "gitBranch": "factory/LAN-1", "message": {"id": "msg_f_send", "model": "claude-opus-5-5", "role": "assistant", "content": [{"type": "tool_use", "id": "toolu_f_send", "name": "SendMessage", "input": {"to": "lantern-orchestrator", "message": "[TF:DONE] LAN-1 is ready for review"}}], "usage": {"input_tokens": 10, "output_tokens": 5}}}');


--
-- Data for Name: session_messages; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.session_messages VALUES ('toolu_a_send', 'claude_code', '11111111-0000-4000-a000-000000000001', '2026-11-20 07:06:30+00', 'lantern-orchestrator', 'DONE', '[TF:DONE] LAN-1 is ready for review');
INSERT INTO tares161fixture.session_messages VALUES ('toolu_b_send', 'claude_code', '11111111-0000-4000-a000-000000000002', '2026-11-20 08:04:30+00', 'lantern-orchestrator', 'DONE', '[TF:DONE] LAN-1 is ready for review');
INSERT INTO tares161fixture.session_messages VALUES ('toolu_c_send', 'cc_old', '11111111-0000-4000-a000-000000000003', '2026-11-20 09:04:30+00', 'lantern-orchestrator', 'DONE', '[TF:DONE] LAN-1 is ready for review');
INSERT INTO tares161fixture.session_messages VALUES ('toolu_d_send', 'claude_code', '11111111-0000-4000-a000-000000000004', '2026-11-10 12:04:30+00', 'lantern-orchestrator', 'DONE', '[TF:DONE] LAN-1 is ready for review');
INSERT INTO tares161fixture.session_messages VALUES ('toolu_e_send', 'claude_code', '11111111-0000-4000-a000-000000000005', '2026-11-20 10:04:30+00', 'lantern-orchestrator', 'DONE', '[TF:DONE] LAN-1 is ready for review');
INSERT INTO tares161fixture.session_messages VALUES ('toolu_f_send', 'claude_code', '11111111-0000-4000-a000-000000000006', '2026-11-20 11:02:30+00', 'lantern-orchestrator', 'DONE', '[TF:DONE] LAN-1 is ready for review');


--
-- Data for Name: session_meters; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: session_moves; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: session_rollup_state; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: session_said; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.session_said VALUES ('11111111-0000-4000-a000-000000000001', 'a-0002', 'claude_code', '2026-11-20 07:01:00+00', 'I will run the tests (round 1).');
INSERT INTO tares161fixture.session_said VALUES ('11111111-0000-4000-a000-000000000001', 'a-0006', 'claude_code', '2026-11-20 07:03:00+00', 'I will run the tests (round 2).');
INSERT INTO tares161fixture.session_said VALUES ('11111111-0000-4000-a000-000000000001', 'a-0010', 'claude_code', '2026-11-20 07:05:00+00', 'I will run the tests (round 3).');
INSERT INTO tares161fixture.session_said VALUES ('11111111-0000-4000-a000-000000000002', 'b-0002', 'claude_code', '2026-11-20 08:01:00+00', 'I will run the tests (round 1).');
INSERT INTO tares161fixture.session_said VALUES ('11111111-0000-4000-a000-000000000002', 'b-0006', 'claude_code', '2026-11-20 08:03:00+00', 'I will run the tests (round 2).');
INSERT INTO tares161fixture.session_said VALUES ('11111111-0000-4000-a000-000000000003', 'c-0002', 'cc_old', '2026-11-20 09:01:00+00', '[thinking] the tests first I will run the tests (round 1).');
INSERT INTO tares161fixture.session_said VALUES ('11111111-0000-4000-a000-000000000003', 'c-0006', 'cc_old', '2026-11-20 09:03:00+00', '[thinking] the tests first I will run the tests (round 2).');
INSERT INTO tares161fixture.session_said VALUES ('11111111-0000-4000-a000-000000000004', 'd-0002', 'claude_code', '2026-11-10 12:01:00+00', 'I will run the tests (round 1).');
INSERT INTO tares161fixture.session_said VALUES ('11111111-0000-4000-a000-000000000004', 'd-0006', 'claude_code', '2026-11-10 12:03:00+00', 'I will run the tests (round 2).');
INSERT INTO tares161fixture.session_said VALUES ('11111111-0000-4000-a000-000000000005', 'e-0002', 'claude_code', '2026-11-20 10:01:00+00', 'I will run the tests (round 1).');
INSERT INTO tares161fixture.session_said VALUES ('11111111-0000-4000-a000-000000000005', 'e-0006', 'claude_code', '2026-11-20 10:03:00+00', 'I will run the tests (round 2).');
INSERT INTO tares161fixture.session_said VALUES ('11111111-0000-4000-a000-000000000006', 'f-0002', 'claude_code', '2026-11-20 11:01:00+00', 'I will run the tests (round 1).');


--
-- Data for Name: session_states; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: session_stations; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.session_stations VALUES ('11111111-0000-4000-a000-000000000001', 'lantern-build-m1', 'builder', 'lantern-orchestrator', 'uc_lantern01', '2026-11-20 07:00:00+00', 'c_038df9d3c0', NULL, NULL);


--
-- Data for Name: session_store_copies; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.session_store_copies VALUES ('session_stations', 0, '2026-11-28 10:11:40.962483+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('session_states', 0, '2026-11-28 10:11:40.968836+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('project_sessions', 0, '2026-11-28 10:11:40.975483+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('session_usage', 0, '2026-11-28 10:11:40.981554+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('session_meters', 0, '2026-11-28 10:11:40.987375+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('settings', 0, '2026-11-28 10:11:40.993754+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('people', 0, '2026-11-28 10:11:41.00023+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('api_keys', 0, '2026-11-28 10:11:41.006386+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('project_members', 0, '2026-11-28 10:11:41.012842+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('usecases', 0, '2026-11-28 10:11:41.019587+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('usecase_objects', 0, '2026-11-28 10:11:41.026478+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('usecase_log', 0, '2026-11-28 10:11:41.033095+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('docs', 0, '2026-11-28 10:11:41.039162+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('skills', 0, '2026-11-28 10:11:41.046412+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('shared_skills', 0, '2026-11-28 10:11:41.052247+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('catalog_sources', 0, '2026-11-28 10:11:41.058259+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('github_credentials', 0, '2026-11-28 10:11:41.064308+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('model_usage', 0, '2026-11-28 10:11:41.070317+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('tickets', 0, '2026-11-28 10:11:41.076942+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('ticket_history', 0, '2026-11-28 10:11:41.082555+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('ticket_numbers', 0, '2026-11-28 10:11:41.088303+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('milestones', 0, '2026-11-28 10:11:41.093836+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('milestone_check_results', 0, '2026-11-28 10:11:41.099627+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('milestone_acceptances', 0, '2026-11-28 10:11:41.107429+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('ticket_checks', 0, '2026-11-28 10:11:41.113558+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('challenges', 0, '2026-11-28 10:11:41.119466+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('reviews', 0, '2026-11-28 10:11:41.125474+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('review_findings', 0, '2026-11-28 10:11:41.131704+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('rule_proposals', 0, '2026-11-28 10:11:41.137454+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('assumptions', 0, '2026-11-28 10:11:41.143173+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('desk_items', 0, '2026-11-28 10:11:41.149205+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('decisions', 0, '2026-11-28 10:11:41.155739+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('handovers', 0, '2026-11-28 10:11:41.162044+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('grants', 0, '2026-11-28 10:11:41.168666+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('pending_memory', 0, '2026-11-28 10:11:41.175028+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('crews', 0, '2026-11-28 10:11:41.182046+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('spec_questions', 0, '2026-11-28 10:11:41.189374+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('signoffs', 0, '2026-11-28 10:11:41.195966+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('handover_overrides', 0, '2026-11-28 10:11:41.202216+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('answers', 0, '2026-11-28 10:11:41.209065+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('waiting_told', 0, '2026-11-28 10:11:41.215388+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('guardrail_rules', 0, '2026-11-28 10:11:41.222554+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('guardrail_pairs', 0, '2026-11-28 10:11:41.228406+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('integration_choices', 0, '2026-11-28 10:11:41.23471+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('integration_connections', 0, '2026-11-28 10:11:41.240848+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('project_integrations', 0, '2026-11-28 10:11:41.24737+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('pending_writeback', 0, '2026-11-28 10:11:41.253468+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('project_secrets', 0, '2026-11-28 10:11:41.259689+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('project_required_checks', 0, '2026-11-28 10:11:41.266102+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('merge_queue', 0, '2026-11-28 10:11:41.272479+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('project_merge_method', 0, '2026-11-28 10:11:41.278475+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('repo_maps', 0, '2026-11-28 10:11:41.285411+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('repo_map_history', 0, '2026-11-28 10:11:41.291492+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('brain_repos', 0, '2026-11-28 10:11:41.297687+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('brain_repo_folders', 0, '2026-11-28 10:11:41.303821+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('brain_repo_updates', 0, '2026-11-28 10:11:41.310089+00');
INSERT INTO tares161fixture.session_store_copies VALUES ('brain_calls', 0, '2026-11-28 10:11:41.316184+00');


--
-- Data for Name: session_store_version; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.session_store_version VALUES ('0024_merge_ledger');


--
-- Data for Name: session_turns; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.session_turns VALUES ('11111111-0000-4000-a000-000000000001', 'a-0001', 'claude_code', '2026-11-20 07:00:30+00', NULL, 'please run the checks, round 1');
INSERT INTO tares161fixture.session_turns VALUES ('11111111-0000-4000-a000-000000000001', 'a-0005', 'claude_code', '2026-11-20 07:02:30+00', NULL, 'please run the checks, round 2');
INSERT INTO tares161fixture.session_turns VALUES ('11111111-0000-4000-a000-000000000001', 'a-0009', 'claude_code', '2026-11-20 07:04:30+00', NULL, 'please run the checks, round 3');
INSERT INTO tares161fixture.session_turns VALUES ('11111111-0000-4000-a000-000000000002', 'b-0001', 'claude_code', '2026-11-20 08:00:30+00', NULL, 'please run the checks, round 1');
INSERT INTO tares161fixture.session_turns VALUES ('11111111-0000-4000-a000-000000000002', 'b-0005', 'claude_code', '2026-11-20 08:02:30+00', NULL, 'please run the checks, round 2');
INSERT INTO tares161fixture.session_turns VALUES ('11111111-0000-4000-a000-000000000003', 'c-0001', 'cc_old', '2026-11-20 09:00:30+00', NULL, 'please run the checks, round 1');
INSERT INTO tares161fixture.session_turns VALUES ('11111111-0000-4000-a000-000000000003', 'c-0005', 'cc_old', '2026-11-20 09:02:30+00', NULL, 'please run the checks, round 2');
INSERT INTO tares161fixture.session_turns VALUES ('11111111-0000-4000-a000-000000000004', 'd-0001', 'claude_code', '2026-11-10 12:00:30+00', NULL, 'please run the checks, round 1');
INSERT INTO tares161fixture.session_turns VALUES ('11111111-0000-4000-a000-000000000004', 'd-0005', 'claude_code', '2026-11-10 12:02:30+00', NULL, 'please run the checks, round 2');
INSERT INTO tares161fixture.session_turns VALUES ('11111111-0000-4000-a000-000000000005', 'e-0001', 'claude_code', '2026-11-20 10:00:30+00', NULL, 'please run the checks, round 1');
INSERT INTO tares161fixture.session_turns VALUES ('11111111-0000-4000-a000-000000000005', 'e-0005', 'claude_code', '2026-11-20 10:02:30+00', NULL, 'please run the checks, round 2');
INSERT INTO tares161fixture.session_turns VALUES ('11111111-0000-4000-a000-000000000006', 'f-0001', 'claude_code', '2026-11-20 11:00:30+00', NULL, 'please run the checks, round 1');


--
-- Data for Name: session_usage; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000001', 'msg_a_0', '2026-11-20 07:01:00+00', 'claude-opus-5-5', 'uc_lantern01', NULL, 100, 20, 5, 50, 0.000835, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000001', 'msg_a_0b', '2026-11-20 07:01:30+00', 'claude-opus-5-5', 'uc_lantern01', NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000001', 'msg_a_1', '2026-11-20 07:03:00+00', 'claude-opus-5-5', 'uc_lantern01', NULL, 101, 20, 5, 50, 0.000839, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000001', 'msg_a_1b', '2026-11-20 07:03:30+00', 'claude-opus-5-5', 'uc_lantern01', NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000001', 'msg_a_2', '2026-11-20 07:05:00+00', 'claude-opus-5-5', 'uc_lantern01', NULL, 102, 20, 5, 50, 0.000843, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000001', 'msg_a_2b', '2026-11-20 07:05:30+00', 'claude-opus-5-5', 'uc_lantern01', NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000001', 'msg_a_send', '2026-11-20 07:06:30+00', 'claude-opus-5-5', 'uc_lantern01', NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000002', 'msg_b_0', '2026-11-20 08:01:00+00', 'claude-opus-5-5', 'uc_harbor002', NULL, 100, 20, 5, 50, 0.000835, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000002', 'msg_b_0b', '2026-11-20 08:01:30+00', 'claude-opus-5-5', 'uc_harbor002', NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000002', 'msg_b_1', '2026-11-20 08:03:00+00', 'claude-opus-5-5', 'uc_harbor002', NULL, 101, 20, 5, 50, 0.000839, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000002', 'msg_b_1b', '2026-11-20 08:03:30+00', 'claude-opus-5-5', 'uc_harbor002', NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000002', 'msg_b_send', '2026-11-20 08:04:30+00', 'claude-opus-5-5', 'uc_harbor002', NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000003', 'msg_c_0', '2026-11-20 09:01:00+00', 'claude-opus-5-5', NULL, NULL, 100, 20, 5, 50, 0.000835, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000003', 'msg_c_0b', '2026-11-20 09:01:30+00', 'claude-opus-5-5', NULL, NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000003', 'msg_c_1', '2026-11-20 09:03:00+00', 'claude-opus-5-5', NULL, NULL, 101, 20, 5, 50, 0.000839, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000003', 'msg_c_1b', '2026-11-20 09:03:30+00', 'claude-opus-5-5', NULL, NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000003', 'msg_c_send', '2026-11-20 09:04:30+00', 'claude-opus-5-5', NULL, NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000004', 'msg_d_0', '2026-11-10 12:01:00+00', 'claude-opus-5-5', 'uc_lantern01', NULL, 100, 20, 5, 50, 0.000835, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000004', 'msg_d_0b', '2026-11-10 12:01:30+00', 'claude-opus-5-5', 'uc_lantern01', NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000004', 'msg_d_1', '2026-11-10 12:03:00+00', 'claude-opus-5-5', 'uc_lantern01', NULL, 101, 20, 5, 50, 0.000839, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000004', 'msg_d_1b', '2026-11-10 12:03:30+00', 'claude-opus-5-5', 'uc_lantern01', NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000004', 'msg_d_send', '2026-11-10 12:04:30+00', 'claude-opus-5-5', 'uc_lantern01', NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000005', 'msg_e_0', '2026-11-20 10:01:00+00', 'claude-opus-5-5', NULL, NULL, 100, 20, 5, 50, 0.000835, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000005', 'msg_e_0b', '2026-11-20 10:01:30+00', 'claude-opus-5-5', NULL, NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000005', 'msg_e_1', '2026-11-20 10:03:00+00', 'claude-opus-5-5', NULL, NULL, 101, 20, 5, 50, 0.000839, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000005', 'msg_e_1b', '2026-11-20 10:03:30+00', 'claude-opus-5-5', NULL, NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000005', 'msg_e_send', '2026-11-20 10:04:30+00', 'claude-opus-5-5', NULL, NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000006', 'msg_f_0', '2026-11-20 11:01:00+00', 'claude-opus-5-5', NULL, NULL, 100, 20, 5, 50, 0.000835, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000006', 'msg_f_0b', '2026-11-20 11:01:30+00', 'claude-opus-5-5', NULL, NULL, 10, 5, 0, 0, 0.00014, 0);
INSERT INTO tares161fixture.session_usage VALUES ('11111111-0000-4000-a000-000000000006', 'msg_f_send', '2026-11-20 11:02:30+00', 'claude-opus-5-5', NULL, NULL, 10, 5, 0, 0, 0.00014, 0);


--
-- Data for Name: session_usage_hourly; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: sessions; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.sessions VALUES ('11111111-0000-4000-a000-000000000001', 'claude_code', '2026-11-20 07:00:00+00', '2026-11-20 07:06:30+00', 15, 4, 1, true, '2026-11-28 10:11:41.844033+00', 'table');
INSERT INTO tares161fixture.sessions VALUES ('11111111-0000-4000-a000-000000000002', 'claude_code', '2026-11-20 08:00:00+00', '2026-11-20 08:04:30+00', 10, 3, 1, true, '2026-11-28 10:11:41.903495+00', 'table');
INSERT INTO tares161fixture.sessions VALUES ('11111111-0000-4000-a000-000000000003', 'cc_old', '2026-11-20 09:00:30+00', '2026-11-20 09:04:30+00', 9, 3, 1, true, '2026-11-28 10:11:41.946642+00', 'table');
INSERT INTO tares161fixture.sessions VALUES ('11111111-0000-4000-a000-000000000004', 'claude_code', '2026-11-10 12:00:00+00', '2026-11-10 12:04:30+00', 10, 3, 1, true, '2026-11-28 10:11:41.992816+00', 'table');
INSERT INTO tares161fixture.sessions VALUES ('11111111-0000-4000-a000-000000000006', 'claude_code', '2026-11-20 11:00:30+00', '2026-11-20 11:02:30+00', 5, 2, 1, true, '2026-11-28 10:11:42.094467+00', 'table');
INSERT INTO tares161fixture.sessions VALUES ('11111111-0000-4000-a000-000000000005', 'claude_code', '2026-11-20 10:00:30+00', '2026-11-20 10:04:30+00', 9, 3, 1, false, '2026-11-28 10:11:42.060485+00', 'table');


--
-- Data for Name: settings; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.settings VALUES ('lineage_backfilled', '1', '2026-11-28 10:11:41.347294+00');
INSERT INTO tares161fixture.settings VALUES ('wiring_moved', '1', '2026-11-28 10:11:41.358192+00');
INSERT INTO tares161fixture.settings VALUES ('skills_shared', '1', '2026-11-28 10:11:41.363166+00');
INSERT INTO tares161fixture.settings VALUES ('factory_kind_filled', '1', '2026-11-28 10:11:41.369259+00');
INSERT INTO tares161fixture.settings VALUES ('sre.incidents_backfilled', '2', '2026-11-28 10:11:41.426681+00');
INSERT INTO tares161fixture.settings VALUES ('edition', 'factory', '2026-11-28 10:11:41.577916+00');


--
-- Data for Name: shared_skills; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.shared_skills VALUES ('deploy', 'How to deploy', 'Run make deploy.', 'uc_lantern01', '2026-11-28 10:11:41.628617+00', '2026-11-28 10:11:41.628617+00', NULL);


--
-- Data for Name: signoffs; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: skills; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: spec_questions; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: tares_state_meta; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.tares_state_meta VALUES ('moved_from_duckdb', '0', '2026-11-28 10:11:41.436023+00');


--
-- Data for Name: ticket_checks; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: ticket_history; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.ticket_history VALUES ('tk_7db9aedf80', 'uc_lantern01', '2026-11-20 09:00:00+00', 'stage', 'review', NULL, 'lantern-build-m1', 'builder', NULL);


--
-- Data for Name: ticket_numbers; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.ticket_numbers VALUES ('uc_lantern01', 3);


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.tickets VALUES ('tk_31865dfed5', 'uc_lantern01', 'tares', NULL, NULL, NULL, 'Ticket 2', 'todo', 3, NULL, '2026-11-28 10:11:41.648881+00', '2026-11-28 10:11:41.648881+00', 'ms_5a657b77e3', NULL, 3, NULL, NULL, NULL, NULL, 'example-org/lantern', NULL, NULL, NULL, NULL);
INSERT INTO tares161fixture.tickets VALUES ('tk_d87f6e8e0f', 'uc_lantern01', 'tares', NULL, NULL, NULL, 'Ticket 0', 'done', 1, NULL, '2026-11-28 10:11:41.64006+00', '2026-11-28 10:11:41.651936+00', 'ms_5a657b77e3', NULL, 1, NULL, 'merged', NULL, NULL, 'example-org/lantern', NULL, NULL, NULL, NULL);
INSERT INTO tares161fixture.tickets VALUES ('tk_7db9aedf80', 'uc_lantern01', 'tares', NULL, NULL, NULL, 'Ticket 1', 'in_progress', 2, NULL, '2026-11-28 10:11:41.645006+00', '2026-11-28 10:11:41.654274+00', 'ms_5a657b77e3', NULL, 2, 'lantern-build-m1', 'review', NULL, '{"url": "https://github.com/example-org/lantern/pull/7", "repo": "example-org/lantern", "number": 7, "head": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "state": "open", "merged": false, "ci": "success"}', 'example-org/lantern', NULL, NULL, 'example-org/lantern', 7);


--
-- Data for Name: trigger_state; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: usecase_log; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.usecase_log VALUES ('uc_lantern01', '2026-11-28 10:11:41.63279+00', 'updated', 'goal set');


--
-- Data for Name: usecase_objects; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.usecase_objects VALUES ('uc_lantern01', 'doc', 'doc:doc_051d096eda', 'doc_051d096eda', false, '2026-11-28 10:11:41.621094+00');
INSERT INTO tares161fixture.usecase_objects VALUES ('uc_harbor002', 'doc', 'doc:doc_051d096eda', 'doc_051d096eda', false, '2026-11-28 10:11:41.624188+00');
INSERT INTO tares161fixture.usecase_objects VALUES ('uc_harbor002', 'doc', 'doc:doc_5c3a3a7eea', 'doc_5c3a3a7eea', false, '2026-11-28 10:11:41.627468+00');
INSERT INTO tares161fixture.usecase_objects VALUES ('uc_lantern01', 'skill', 'skill:deploy', 'deploy', false, '2026-11-28 10:11:41.631257+00');
INSERT INTO tares161fixture.usecase_objects VALUES ('uc_lantern01', 'source', 'source:gh-poll', 'gh-poll', false, '2026-11-20 12:00:00+00');
INSERT INTO tares161fixture.usecase_objects VALUES ('uc_harbor002', 'source', '+source:claude_code', 'claude_code', false, '2026-11-28 10:11:41.87962+00');
INSERT INTO tares161fixture.usecase_objects VALUES ('uc_lantern01', 'source', '+source:claude_code', 'claude_code', false, '2026-11-28 10:11:41.81235+00');


--
-- Data for Name: usecases; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--

INSERT INTO tares161fixture.usecases VALUES ('uc_lantern01', 'custom', 'Lantern billing', '{}', 'active', '2026-11-28 10:11:41.598529+00', '2026-11-28 10:11:41.598529+00', NULL, 'Make billing fast.', NULL, NULL, NULL, 'software_factory', 'p_0db1325ec6', 'team', NULL);
INSERT INTO tares161fixture.usecases VALUES ('uc_harbor002', 'custom', 'Harbor search', '{}', 'active', '2026-11-28 10:11:41.603564+00', '2026-11-28 10:11:41.603564+00', NULL, 'Search that answers.', NULL, NULL, NULL, 'software_factory', NULL, 'team', NULL);
INSERT INTO tares161fixture.usecases VALUES ('uc_default03', 'default', 'Default', '{}', 'active', '2026-11-28 10:11:41.607753+00', '2026-11-28 10:11:41.607753+00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'team', NULL);
INSERT INTO tares161fixture.usecases VALUES ('uc_challeng4', 'challenger_workflow', 'Challenger', '{}', 'active', '2026-11-28 10:11:41.611016+00', '2026-11-28 10:11:41.611016+00', NULL, 'Challenge commits.', NULL, NULL, NULL, NULL, NULL, 'team', NULL);


--
-- Data for Name: waiting_told; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Data for Name: watch_state; Type: TABLE DATA; Schema: tares161fixture; Owner: -
--



--
-- Name: agent_runs agent_runs_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.agent_runs
    ADD CONSTRAINT agent_runs_pkey PRIMARY KEY (id);


--
-- Name: answers answers_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.answers
    ADD CONSTRAINT answers_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: ask_sessions ask_sessions_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.ask_sessions
    ADD CONSTRAINT ask_sessions_pkey PRIMARY KEY (id);


--
-- Name: assumptions assumptions_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.assumptions
    ADD CONSTRAINT assumptions_pkey PRIMARY KEY (id);


--
-- Name: brain_calls brain_calls_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.brain_calls
    ADD CONSTRAINT brain_calls_pkey PRIMARY KEY (id);


--
-- Name: brain_repo_folders brain_repo_folders_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.brain_repo_folders
    ADD CONSTRAINT brain_repo_folders_pkey PRIMARY KEY (repo, path);


--
-- Name: brain_repo_updates brain_repo_updates_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.brain_repo_updates
    ADD CONSTRAINT brain_repo_updates_pkey PRIMARY KEY (id);


--
-- Name: brain_repos brain_repos_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.brain_repos
    ADD CONSTRAINT brain_repos_pkey PRIMARY KEY (repo);


--
-- Name: catalog_agents catalog_agents_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.catalog_agents
    ADD CONSTRAINT catalog_agents_pkey PRIMARY KEY (name);


--
-- Name: catalog_sources catalog_sources_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.catalog_sources
    ADD CONSTRAINT catalog_sources_pkey PRIMARY KEY (name);


--
-- Name: catalog_triggers catalog_triggers_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.catalog_triggers
    ADD CONSTRAINT catalog_triggers_pkey PRIMARY KEY (name);


--
-- Name: challenges challenges_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.challenges
    ADD CONSTRAINT challenges_pkey PRIMARY KEY (source, key_value, event_time, event_type, branch);


--
-- Name: crews crews_person_id_name_machine_key; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.crews
    ADD CONSTRAINT crews_person_id_name_machine_key UNIQUE (person_id, name, machine);


--
-- Name: crews crews_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.crews
    ADD CONSTRAINT crews_pkey PRIMARY KEY (id);


--
-- Name: decisions decisions_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.decisions
    ADD CONSTRAINT decisions_pkey PRIMARY KEY (id);


--
-- Name: desk_items desk_items_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.desk_items
    ADD CONSTRAINT desk_items_pkey PRIMARY KEY (id);


--
-- Name: dispatch_log dispatch_log_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.dispatch_log
    ADD CONSTRAINT dispatch_log_pkey PRIMARY KEY (dispatch_id);


--
-- Name: dispatch_projects dispatch_projects_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.dispatch_projects
    ADD CONSTRAINT dispatch_projects_pkey PRIMARY KEY (dispatch_id, project);


--
-- Name: docs docs_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.docs
    ADD CONSTRAINT docs_pkey PRIMARY KEY (id);


--
-- Name: finding_feedback finding_feedback_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.finding_feedback
    ADD CONSTRAINT finding_feedback_pkey PRIMARY KEY (run_id, person);


--
-- Name: github_credentials github_credentials_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.github_credentials
    ADD CONSTRAINT github_credentials_pkey PRIMARY KEY (name);


--
-- Name: grants grants_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.grants
    ADD CONSTRAINT grants_pkey PRIMARY KEY (id);


--
-- Name: guardrail_pairs guardrail_pairs_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.guardrail_pairs
    ADD CONSTRAINT guardrail_pairs_pkey PRIMARY KEY (id);


--
-- Name: guardrail_rules guardrail_rules_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.guardrail_rules
    ADD CONSTRAINT guardrail_rules_pkey PRIMARY KEY (id);


--
-- Name: handovers handovers_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.handovers
    ADD CONSTRAINT handovers_pkey PRIMARY KEY (project);


--
-- Name: incident_notes incident_notes_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.incident_notes
    ADD CONSTRAINT incident_notes_pkey PRIMARY KEY (run_id);


--
-- Name: incidents incidents_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.incidents
    ADD CONSTRAINT incidents_pkey PRIMARY KEY (id);


--
-- Name: integration_choices integration_choices_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.integration_choices
    ADD CONSTRAINT integration_choices_pkey PRIMARY KEY (slot);


--
-- Name: integration_connections integration_connections_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.integration_connections
    ADD CONSTRAINT integration_connections_pkey PRIMARY KEY (slot, name);


--
-- Name: mcp_servers mcp_servers_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.mcp_servers
    ADD CONSTRAINT mcp_servers_pkey PRIMARY KEY (name);


--
-- Name: merge_queue merge_queue_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.merge_queue
    ADD CONSTRAINT merge_queue_pkey PRIMARY KEY (id);


--
-- Name: merge_records merge_records_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.merge_records
    ADD CONSTRAINT merge_records_pkey PRIMARY KEY (queue_row);


--
-- Name: milestone_acceptances milestone_acceptances_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.milestone_acceptances
    ADD CONSTRAINT milestone_acceptances_pkey PRIMARY KEY (milestone);


--
-- Name: milestone_check_results milestone_check_results_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.milestone_check_results
    ADD CONSTRAINT milestone_check_results_pkey PRIMARY KEY (id);


--
-- Name: milestones milestones_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.milestones
    ADD CONSTRAINT milestones_pkey PRIMARY KEY (id);


--
-- Name: model_usage model_usage_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.model_usage
    ADD CONSTRAINT model_usage_pkey PRIMARY KEY (id);


--
-- Name: pending_memory pending_memory_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.pending_memory
    ADD CONSTRAINT pending_memory_pkey PRIMARY KEY (id);


--
-- Name: pending_writeback pending_writeback_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.pending_writeback
    ADD CONSTRAINT pending_writeback_pkey PRIMARY KEY (ticket, integration);


--
-- Name: people people_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.people
    ADD CONSTRAINT people_pkey PRIMARY KEY (id);


--
-- Name: project_integrations project_integrations_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.project_integrations
    ADD CONSTRAINT project_integrations_pkey PRIMARY KEY (project_uid, slot);


--
-- Name: project_members project_members_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.project_members
    ADD CONSTRAINT project_members_pkey PRIMARY KEY (project, person_id);


--
-- Name: project_merge_method project_merge_method_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.project_merge_method
    ADD CONSTRAINT project_merge_method_pkey PRIMARY KEY (project);


--
-- Name: project_required_checks project_required_checks_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.project_required_checks
    ADD CONSTRAINT project_required_checks_pkey PRIMARY KEY (project);


--
-- Name: project_secrets project_secrets_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.project_secrets
    ADD CONSTRAINT project_secrets_pkey PRIMARY KEY (project, name);


--
-- Name: project_sessions project_sessions_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.project_sessions
    ADD CONSTRAINT project_sessions_pkey PRIMARY KEY (project, session);


--
-- Name: query_log query_log_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.query_log
    ADD CONSTRAINT query_log_pkey PRIMARY KEY (id);


--
-- Name: repo_maps repo_maps_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.repo_maps
    ADD CONSTRAINT repo_maps_pkey PRIMARY KEY (repo);


--
-- Name: report_texts report_texts_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.report_texts
    ADD CONSTRAINT report_texts_pkey PRIMARY KEY (kind, key);


--
-- Name: report_weeks report_weeks_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.report_weeks
    ADD CONSTRAINT report_weeks_pkey PRIMARY KEY (project, week);


--
-- Name: review_findings review_findings_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.review_findings
    ADD CONSTRAINT review_findings_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: rule_proposals rule_proposals_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.rule_proposals
    ADD CONSTRAINT rule_proposals_pkey PRIMARY KEY (id);


--
-- Name: run_projects run_projects_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.run_projects
    ADD CONSTRAINT run_projects_pkey PRIMARY KEY (run_id, project);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (name);


--
-- Name: session_archive_parts session_archive_parts_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_archive_parts
    ADD CONSTRAINT session_archive_parts_pkey PRIMARY KEY (session, part);


--
-- Name: session_commands session_commands_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_commands
    ADD CONSTRAINT session_commands_pkey PRIMARY KEY (tool_use_id);


--
-- Name: session_files session_files_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_files
    ADD CONSTRAINT session_files_pkey PRIMARY KEY (session, path);


--
-- Name: session_ingest_marks session_ingest_marks_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_ingest_marks
    ADD CONSTRAINT session_ingest_marks_pkey PRIMARY KEY (name);


--
-- Name: session_lines session_lines_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_lines
    ADD CONSTRAINT session_lines_pkey PRIMARY KEY (session, seq);


--
-- Name: session_messages session_messages_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_messages
    ADD CONSTRAINT session_messages_pkey PRIMARY KEY (tool_use_id);


--
-- Name: session_meters session_meters_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_meters
    ADD CONSTRAINT session_meters_pkey PRIMARY KEY (session);


--
-- Name: session_moves session_moves_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_moves
    ADD CONSTRAINT session_moves_pkey PRIMARY KEY (session);


--
-- Name: session_rollup_state session_rollup_state_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_rollup_state
    ADD CONSTRAINT session_rollup_state_pkey PRIMARY KEY (name);


--
-- Name: session_said session_said_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_said
    ADD CONSTRAINT session_said_pkey PRIMARY KEY (session, line_key);


--
-- Name: session_states session_states_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_states
    ADD CONSTRAINT session_states_pkey PRIMARY KEY (session);


--
-- Name: session_stations session_stations_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_stations
    ADD CONSTRAINT session_stations_pkey PRIMARY KEY (session);


--
-- Name: session_store_copies session_store_copies_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_store_copies
    ADD CONSTRAINT session_store_copies_pkey PRIMARY KEY (table_name);


--
-- Name: session_store_version session_store_version_pkc; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_store_version
    ADD CONSTRAINT session_store_version_pkc PRIMARY KEY (version_num);


--
-- Name: session_turns session_turns_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_turns
    ADD CONSTRAINT session_turns_pkey PRIMARY KEY (session, line_key);


--
-- Name: session_usage_hourly session_usage_hourly_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_usage_hourly
    ADD CONSTRAINT session_usage_hourly_pkey PRIMARY KEY (session, hour, project);


--
-- Name: session_usage session_usage_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.session_usage
    ADD CONSTRAINT session_usage_pkey PRIMARY KEY (session, message);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (session);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (key);


--
-- Name: shared_skills shared_skills_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.shared_skills
    ADD CONSTRAINT shared_skills_pkey PRIMARY KEY (name);


--
-- Name: signoffs signoffs_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.signoffs
    ADD CONSTRAINT signoffs_pkey PRIMARY KEY (project, repo);


--
-- Name: skills skills_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.skills
    ADD CONSTRAINT skills_pkey PRIMARY KEY (project, name);


--
-- Name: spec_questions spec_questions_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.spec_questions
    ADD CONSTRAINT spec_questions_pkey PRIMARY KEY (project, id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (subscription_id);


--
-- Name: tares_state_meta tares_state_meta_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.tares_state_meta
    ADD CONSTRAINT tares_state_meta_pkey PRIMARY KEY (key);


--
-- Name: ticket_checks ticket_checks_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.ticket_checks
    ADD CONSTRAINT ticket_checks_pkey PRIMARY KEY (id);


--
-- Name: ticket_numbers ticket_numbers_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.ticket_numbers
    ADD CONSTRAINT ticket_numbers_pkey PRIMARY KEY (project);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: trigger_state trigger_state_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.trigger_state
    ADD CONSTRAINT trigger_state_pkey PRIMARY KEY (trigger, key_value);


--
-- Name: usecase_objects usecase_objects_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.usecase_objects
    ADD CONSTRAINT usecase_objects_pkey PRIMARY KEY (usecase_id, kind, key);


--
-- Name: usecases usecases_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.usecases
    ADD CONSTRAINT usecases_pkey PRIMARY KEY (id);


--
-- Name: waiting_told waiting_told_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.waiting_told
    ADD CONSTRAINT waiting_told_pkey PRIMARY KEY (person_id, item);


--
-- Name: watch_state watch_state_pkey; Type: CONSTRAINT; Schema: tares161fixture; Owner: -
--

ALTER TABLE ONLY tares161fixture.watch_state
    ADD CONSTRAINT watch_state_pkey PRIMARY KEY (service);


--
-- Name: idx_answers_at; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX idx_answers_at ON tares161fixture.answers USING btree (answered_at);


--
-- Name: idx_brain_repo_updates_repo; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX idx_brain_repo_updates_repo ON tares161fixture.brain_repo_updates USING btree (repo, at);


--
-- Name: idx_merge_queue_repo; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX idx_merge_queue_repo ON tares161fixture.merge_queue USING btree (repo, base);


--
-- Name: ix_agent_runs_agent; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX ix_agent_runs_agent ON tares161fixture.agent_runs USING btree (agent);


--
-- Name: ix_challenges_branch; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX ix_challenges_branch ON tares161fixture.challenges USING btree (source, branch);


--
-- Name: ix_model_usage_ts; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX ix_model_usage_ts ON tares161fixture.model_usage USING btree (ts);


--
-- Name: merge_records_project_merged_at; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX merge_records_project_merged_at ON tares161fixture.merge_records USING btree (project, merged_at);


--
-- Name: project_sessions_session; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX project_sessions_session ON tares161fixture.project_sessions USING btree (session);


--
-- Name: session_commands_session_at; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX session_commands_session_at ON tares161fixture.session_commands USING btree (session, at);


--
-- Name: session_files_session_last_at; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX session_files_session_last_at ON tares161fixture.session_files USING btree (session, last_at);


--
-- Name: session_lines_session_at; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX session_lines_session_at ON tares161fixture.session_lines USING btree (session, at);


--
-- Name: session_messages_session_at; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX session_messages_session_at ON tares161fixture.session_messages USING btree (session, at);


--
-- Name: session_moves_state; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX session_moves_state ON tares161fixture.session_moves USING btree (state);


--
-- Name: session_said_session_at; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX session_said_session_at ON tares161fixture.session_said USING btree (session, at);


--
-- Name: session_turns_at; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX session_turns_at ON tares161fixture.session_turns USING btree (at);


--
-- Name: session_turns_session_at; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX session_turns_session_at ON tares161fixture.session_turns USING btree (session, at);


--
-- Name: session_usage_hourly_hour; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX session_usage_hourly_hour ON tares161fixture.session_usage_hourly USING btree (hour);


--
-- Name: session_usage_replied_at; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX session_usage_replied_at ON tares161fixture.session_usage USING btree (replied_at);


--
-- Name: sessions_last_line_at; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX sessions_last_line_at ON tares161fixture.sessions USING btree (last_line_at);


--
-- Name: ticket_history_ticket; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX ticket_history_ticket ON tares161fixture.ticket_history USING btree (ticket);


--
-- Name: tickets_pr; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX tickets_pr ON tares161fixture.tickets USING btree (pr_repo, pr_number);


--
-- Name: tickets_project; Type: INDEX; Schema: tares161fixture; Owner: -
--

CREATE INDEX tickets_project ON tares161fixture.tickets USING btree (project);


--
-- PostgreSQL database dump complete
--

\unrestrict OtOFxxfQjP3P1oxI0HrK7WMJvIlhTG0JRrdF0iR6xX8IbFIVyefaQ2lXvdsvM11

